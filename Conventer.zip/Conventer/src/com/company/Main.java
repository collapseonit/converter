package com.company;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static BufferedReader reader;
    public static String time = null;
    public static String zone = null;
    public static int hours;
    public static int timeZone;
    public static char timeSetts;
    public static String min;

    public static void getIn(){
        try {
            System.out.println("Input the time as HH:MM or HH:MM a.m (or p.m):");
            time = reader.readLine();
            time+=" ";
            System.out.println("Choose the time zone (for example: 5 or -4):");
            zone = reader.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void checkingTheTimeSettings(){
        if (time.contains("m")){
            timeSetts = time.charAt(time.indexOf(".")-1);
            if (timeSetts == 'a' && hours>=12) { hours-=12;  timeSetts = 'p';}
            if (timeSetts == 'p' && hours>=12) { hours-=12;  timeSetts = 'a';}
            System.out.println(hours+":"+min+" "+timeSetts+".m");

        }else {
                if (hours>=24) {
                    hours -= 24;
                }
            System.out.println(hours+":"+min);
        }
    }

    public static void main(String[] args) {
        reader = new BufferedReader(new InputStreamReader(System.in));
        getIn();
        String h = time.substring(0,time.indexOf(":"));
        min = time.substring(time.indexOf(":")+1,time.indexOf(" "));
        hours = Integer.parseInt(h);
        timeZone = Integer.parseInt(zone);
        hours += timeZone - 2;
        checkingTheTimeSettings();
    }
}
